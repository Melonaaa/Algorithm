package programmers_Lv1_21정수론;
import java.util.Arrays;

public class S7_최대공약수최소공배수 {
    public static int[] solution(int n, int m) {
        int[] answer = new int[2];
        int min = (n<m)?n:m;
       
        for (int i=1; i<=min; i++)
            if (n%i==0 && m%i==0) {
                answer[0]=i;
                answer[1]=n*m/i;
            }
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(Arrays.toString(solution(3,12)));
        System.out.println(Arrays.toString(solution(2,5)));
	}
}
