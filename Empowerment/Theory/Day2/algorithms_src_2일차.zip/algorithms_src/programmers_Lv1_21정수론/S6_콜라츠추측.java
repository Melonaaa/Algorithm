package programmers_Lv1_21정수론;

public class S6_콜라츠추측 {
    public static int solution(long num) {
        int answer = 0;
        while (num!=1){
            if(num%2==0) num/=2;
            else num = num*3+1;
            answer++;
        }
        if (answer<=500) return answer;
        else return -1;
    }
	public static void main(String[] args) {
        System.out.println(solution(6));
        System.out.println(solution(16));
        System.out.println(solution(626331));
	}
}
