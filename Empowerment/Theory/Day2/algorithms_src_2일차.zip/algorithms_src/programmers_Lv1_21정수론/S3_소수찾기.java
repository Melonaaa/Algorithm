package programmers_Lv1_21정수론;

public class S3_소수찾기 { //시간복잡도 고려 안하면 실패
    public static int solution(int n) {
        int answer = 1;
        int count = 0;
        for(int a=3; a<=n; a++) {
            for(int b=2; b<=Math.sqrt(a); b++) // b<a 과의 시간 복잡도 비교
                if(a%b==0) { 
                	count=1; 
                	break; 
                }
            if (count==0) answer++;
            else count=0;
        }
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution(10));
        System.out.println(solution(5));
	}

}
