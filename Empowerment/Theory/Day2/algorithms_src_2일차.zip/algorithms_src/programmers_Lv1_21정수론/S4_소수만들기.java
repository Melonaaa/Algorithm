package programmers_Lv1_21정수론;

public class S4_소수만들기 {
    public static int solution(int[] nums) {
        int answer = 0;
        int count;
        for(int a=0; a<nums.length-2; a++) {
            for(int b=a+1; b<nums.length-1; b++) {
                for(int c=b+1; c<nums.length; c++) {
                	int sum = nums[a]+nums[b]+nums[c];
                    count=0;                        
                    for(int x=2; x<=Math.sqrt(sum); x++) // x<sum 과의 시간 복잡도 비교
                        if(sum%x==0) {
                            count++;
                            break;
                        }
                    if (count==0) answer++;
                }
            }
        }
        return answer;
    }
	public static void main(String[] args) {
		int[] nums1 = {1,2,3,4};
		int[] nums2 = {1,2,7,6,4};
        System.out.println(solution(nums1));
        System.out.println(solution(nums2));
	}
}
