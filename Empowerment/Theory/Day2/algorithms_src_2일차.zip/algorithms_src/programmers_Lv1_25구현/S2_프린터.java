package programmers_Lv1_25구현;
import java.util.*;
public class S2_프린터 {
    public static int solution(int[] priorities, int location) {
        int answer = 0;
        Queue<Integer> que = new LinkedList<>();
        for(int p : priorities) que.add(p);

        Arrays.sort(priorities);
        int len = priorities.length-1;

        while(!que.isEmpty()){
            System.out.println("중요도 목록 " + que);
            int curr = que.poll();
            
            System.out.print("꺼낸 중요도 "+curr + " 큰 중요도 "+priorities[len-answer] + "\n");
            if(curr == priorities[len-answer]) { // 꺼낸 중요도와 가강 큰 중요도 같으면
                answer++;
                System.out.println(answer + "번째" + " 인쇄");

                location--;
                if(location < 0) break;
            } else {  // 꺼낸 중요도 가강 큰 중요가 아니면 맨 뒤로 추가
                que.add(curr);
                location--;
                if(location < 0) location = que.size()-1;
            }
        }
        return answer;
    }
    public static void main(String[] args) {
        int[] priorities1 = {2, 1, 3, 2};
    	int[] priorities2 = {1, 1, 9, 1, 1, 1};
        int result;
        result = solution(priorities1, 2);
        System.out.println("요청한 작업: " + result + "번째 인쇄");
        result = solution(priorities2, 0);
        System.out.println("요청한 작업: " + result + "번째 인쇄");
    }  
}
