package programmers_Lv1_22해시;
import java.util.*;

public class S2_완주하지못한선수 {
    public String solution(String[] participant, String[] completion) {
        String answer = "";
        int i;
        Arrays.sort(participant);
        Arrays.sort(completion);
        
        for(i=0; i<completion.length; i++)
            if (!participant[i].equals(completion[i])) {
                answer += participant[i];
                break;
            }    
        if(answer=="") 
            answer += participant[i];
        return answer;
    }
	public static void main(String[] args) {
		String[] participant1 = {"leo", "kiki", "eden"};
		String[] participant2 = {"marina", "josipa", "nikola", "vinko", "filipa"};
		String[] participant3 = {"mislav", "stanko", "mislav", "ana"};
		String[] completion1 = {"eden", "kiki"};
		String[] completion2 = {"josipa", "filipa", "marina", "nikola"};
		String[] completion3 = {"stanko", "ana", "mislav"};		
		S2_완주하지못한선수 sol = new S2_완주하지못한선수();
        System.out.println(sol.solution(participant1, completion1));
        System.out.println(sol.solution(participant2, completion2));
        System.out.println(sol.solution(participant3, completion3));
	}

}
