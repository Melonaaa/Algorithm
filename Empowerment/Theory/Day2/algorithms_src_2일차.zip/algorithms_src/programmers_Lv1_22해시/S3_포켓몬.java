package programmers_Lv1_22해시;
import java.util.*;

public class S3_포켓몬 {
    public static int solution(int[] nums) {
        int answer = 0;
        HashSet <Integer> set = new HashSet<>();
        for (int n : nums) {
            set.add(n);            
        }
        if(set.size()>nums.length/2)
            answer = nums.length/2;
        else answer = set.size();
        
        return answer;
    }
	public static void main(String[] args) {
		int[] nums1 = {3,1,2,3};
		int[] nums2= {3,3,3,2,2,4};
		int[] nums3 = {3,3,3,2,2,2};
        System.out.println(solution(nums1));
        System.out.println(solution(nums2));
        System.out.println(solution(nums3));
	}
}
