package programmers_Lv1_22해시;
import java.util.*;
public class S22_완주하지못한선수_해시 {
    public static String solution(String[] participant, String[] completion) {
        String answer = "";
        HashMap<String, Integer> map = new HashMap<>();
        for (String player : participant) 
            map.put(player, map.getOrDefault(player, 0) + 1); // getOrDefault : 키가 없음 0, 있음 값 가져와 +1
        for (String player : completion) 
            map.put(player, map.get(player) - 1);

        for(String key : map.keySet())
        	if(map.get(key) != 0) {
        		answer = key;
        		break;
        	}
        return answer;
    }
	public static void main(String[] args) {
        String[] part1 = {"leo", "kiki", "eden"};
        String[] comp1 = {"eden", "kiki"};
		String[] part2 = {"marina", "josipa", "nikola", "vinko", "filipa"};
		String[] comp2 = {"josipa", "filipa", "marina", "nikola"};
		String[] part3 = {"mislav", "stanko", "mislav", "ana"};
		String[] comp3 = {"stanko", "ana", "mislav"};   		
        System.out.println(solution(part1, comp1));
        System.out.println(solution(part2, comp2));
        System.out.println(solution(part3, comp3));
	}
}
