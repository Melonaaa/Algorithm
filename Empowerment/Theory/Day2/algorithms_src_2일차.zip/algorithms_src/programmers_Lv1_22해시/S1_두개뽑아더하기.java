package programmers_Lv1_22해시;
import java.util.*;

public class S1_두개뽑아더하기 {
    public static int[] solution(int[] numbers) {
        int[] answer;
        int index=0;
        HashSet<Integer> set = new HashSet<>();
        for(int i=0; i<numbers.length; i++)
            for(int j=i+1; j<numbers.length; j++)
            	set.add(numbers[i]+numbers[j]);

        answer = new int[set.size()];
        for (int n : set)
        	answer[index++] = n;
        Arrays.sort(answer);
        return answer;
    }
	public static void main(String[] args) {
		int[] arr1 = {2,1,3,4,1};
		int[] arr2 = {5,0,2,7};
		System.out.println(Arrays.toString(solution(arr1)));
		System.out.println(Arrays.toString(solution(arr2)));
	}
}
