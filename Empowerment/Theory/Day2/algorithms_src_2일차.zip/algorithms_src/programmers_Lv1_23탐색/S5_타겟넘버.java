package programmers_Lv1_23탐색;

public class S5_타겟넘버 { 
    int answer;
    public int solution(int[] numbers, int target) {
        answer = 0;
        dfs(numbers, target, 0, 0);
        return answer;
    }
    void dfs(int[] numbers, int target, int index, int sum) {		// 깊이우선탐색
        if(index == numbers.length) {
            //System.out.println("합:"+(sum));
            if(sum == target)
                answer++;
            return;
        }
        //System.out.print(numbers[index] + " ");
        dfs(numbers, target, index+1, sum+numbers[index]);
        //System.out.println("");
        //System.out.print(-numbers[index] + " ");
        dfs(numbers, target, index+1, sum-numbers[index]);
    }
    public static void main(String[] args) {
        int[] numbers1 = {1,1,1,1,1};
        int[] numbers2 = {4, 1, 2, 1};
        
        S5_타겟넘버 sol = new S5_타겟넘버();
        System.out.println("타겟넘버 생성 방법: " + sol.solution(numbers1, 3) + "가지");
        System.out.println("타겟넘버 생성 방법: " + sol.solution(numbers2, 4) + "가지"); 
    }    
}
