package programmers_Lv1_23탐색;
import java.util.Arrays;
public class S4_이분탐색 {
	private static int solution(int[] arr, int target) {
		int start = 0;
		int end = arr.length-1;
		while(start<=end) {
			int mid = (start+end)/2;
			System.out.println("접근 중간값: " + arr[mid]);
			if(target==arr[mid]) 
				return mid;
			else if (target>arr[mid])
				start = mid+1;
			else
				end = mid-1;
		}
		return -1;
	}
	public static void main(String[] args) {
		int[] arr = {1 ,2, 3, 4, 5, 6};
		int result = 0;
    	System.out.println(Arrays.toString(arr));
    	
		result = solution(arr, 4);
        if (result == -1)
			System.out.println("이분 탐색 실패: 찾는 값이 없음");
        else
        	System.out.println("이분 탐색 성공: 인덱스" + result + "에서 찾음");
	}
}
