package programmers_Lv1_23탐색;
import java.util.*;

public class S1_모의고사 { // 완전탐색
    public static int[] solution(int[] answers) {
        int[] a = {1, 2, 3, 4, 5};
        int[] b = {2, 1, 2, 3, 2, 4, 2, 5};
        int[] c = {3, 3, 1, 1, 2, 2, 4, 4, 5, 5};
        int[] score = new int[3];

        for(int i=0; i<answers.length; i++) {
            if(answers[i] == a[i%a.length]) score[0]++;
            if(answers[i] == b[i%b.length]) score[1]++;
            if(answers[i] == c[i%c.length]) score[2]++;
        }
        int maxScore = Math.max(score[0], Math.max(score[1], score[2]));
        ArrayList<Integer> arrList = new ArrayList<>();
        for(int i=0; i<score.length; i++)
        	if(maxScore == score[i]) arrList.add(i+1);
        
        int[] answer = new int[arrList.size()];
        for(int i=0; i<arrList.size(); i++)
            answer[i] = arrList.get(i);
        return answer;
    }
	public static void main(String[] args) {
		int[] answer1 = {1,2,3,4,5};
		int[] answer2 = {1,3,2,4,2};
        System.out.println(Arrays.toString(solution(answer1)));
        System.out.println(Arrays.toString(solution(answer2)));
	}
}
