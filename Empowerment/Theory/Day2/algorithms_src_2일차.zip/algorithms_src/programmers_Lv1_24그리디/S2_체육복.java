package programmers_Lv1_24그리디;

public class S2_체육복 {
    public static int solution(int n, int[] lost, int[] reserve) {
        int answer = n;
        int[] pp = new int[n];
        for(int los : lost) pp[los-1]--;
        for(int reser : reserve) pp[reser-1]++;

        for(int i=0; i<pp.length; i++)
            if(pp[i]==-1) {
                if(i-1>=0 && pp[i-1]==1) {
                    pp[i-1]--;
                    pp[i]++;
                } else if (i+1<pp.length && pp[i+1]==1) {
                    pp[i+1]--;
                    pp[i]++;
                } else answer--;
            }
        return answer;        
    }
	public static void main(String[] args) {				
		int[] lost1 = {2, 4};
		int[] reserve1 = {1, 3, 5};
		int[] lost2 = {2, 4};
		int[] reserve2 = {3};
		int[] lost3 = {3};
		int[] reserve3 = {1};
        System.out.println(solution(5,lost1,reserve1));
        System.out.println(solution(5,lost2,reserve2));
        System.out.println(solution(3,lost3,reserve3));
	}
}
