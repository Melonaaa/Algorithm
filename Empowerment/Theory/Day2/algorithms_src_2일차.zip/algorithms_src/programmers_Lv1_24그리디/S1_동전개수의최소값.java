package programmers_Lv1_24그리디;

public class S1_동전개수의최소값 {
    public static int solution(int k) {
    	int[] coin = {1, 5, 10, 50, 100, 500};
        int answer = 0;
        for (int i = coin.length-1; i>=0; i--)
          if (k >= coin[i]) { // 현재 동전의 가치가 K보다 작거나 같으면 구성에 추가
        	  answer += (k / coin[i]);
        	  k = k % coin[i]; // K를 현재 동전을 사용하고 남은 금액으로 업데이트
          }
        return answer;
    }
	public static void main(String[] args) {	
        System.out.println(solution(100000));
        System.out.println(solution(4200));
	}
}
