package programmers_Lv1_20;
import java.util.Arrays;
public class S7_Lv2_가장큰수 {
    public static String solution(int[] numbers) {
        String answer = "";
        String[] arr = new String[numbers.length];
        
        for (int i = 0; i < numbers.length; i++) {
            arr[i] = String.valueOf(numbers[i]);
        }
        Arrays.sort(arr, (a, b) -> (b+a).compareTo(a+b));	    // 내림차순
        // Arrays.sort(arr, (a, b) -> (a+b).compareTo(b+a));    // 오름차순
        /*
 		오름차순 : (o1+o2).compareTo(o2+o1)
        내림차순 : (o2+o1).compareTo(o1+o2)
        5와 9 비교시.. ("9"+"5").compareTo("5"+"9")
        95.compareTo(59) 
        */
        StringBuilder sb = new StringBuilder();
        for (String s : arr)
            sb.append(s);

        answer = sb.toString();
        if (answer.charAt(0) == '0') return "0";
        return answer;        
    }
	public static void main(String[] args) {
		int[] numbers = {6, 10, 2};
		//System.out.println(solution(numbers));
		System.out.println(("9"+"5").compareTo("5"+"9"));
		System.out.println(("5"+"9").compareTo("9"+"5"));
	}
}
