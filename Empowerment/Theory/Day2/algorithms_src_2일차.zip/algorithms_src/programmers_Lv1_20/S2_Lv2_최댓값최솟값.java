package programmers_Lv1_20;
import java.util.*;
public class S2_Lv2_최댓값최솟값 {
    public static String solution(String s) {
        String answer = "";
        ArrayList<Integer> arrList = new ArrayList<>();
        String[] str = s.split(" ");

        for(int i=0; i<str.length; i++) 
            arrList.add(Integer.parseInt(str[i]));
            
        answer = Collections.min(arrList) + " " + Collections.max(arrList);        
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution("1 2 3 4"));
        System.out.println(solution("-1 -2 -3 -4"));
        System.out.println(solution("-1 -1"));
	}
}
