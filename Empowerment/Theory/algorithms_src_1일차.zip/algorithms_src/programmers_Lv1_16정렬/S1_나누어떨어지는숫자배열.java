package programmers_Lv1_16정렬;
import java.util.*;
public class S1_나누어떨어지는숫자배열 {
    public static int[] solution(int[] arr, int divisor) {
        int[] answer;
        ArrayList<Integer> arrlist = new ArrayList<>();
        for (int i=0; i<arr.length; i++)
            if(arr[i]%divisor==0)
            	arrlist.add(arr[i]);
        
        Collections.sort(arrlist); 
        if (arrlist.size()==0)
            answer = new int[] {-1};
        else {
            answer = new int[arrlist.size()];            
            for (int i=0; i<arrlist.size(); i++)
                answer[i] = arrlist.get(i);
        }
        return answer;
    }
	public static void main(String[] args) {
		int[] arr1 = {5, 9, 7, 10};
		int[] arr2 = {2, 36, 1, 3};
		int[] arr3 = {3,2,6};
		System.out.println(Arrays.toString(solution(arr1, 5)));
		System.out.println(Arrays.toString(solution(arr2, 1)));
		System.out.println(Arrays.toString(solution(arr3, 10)));
	}
}
