package programmers_Lv1_16정렬;
import java.util.*;

public class S2_예산 {
    public static int solution(int[] d, int budget) {
        int answer = 0;
        Arrays.sort(d);
        for(int i=0; i<d.length; i++) {
            budget -= d[i];
            if (budget < 0) break;
            answer++;
        }
        return answer;
    }
	public static void main(String[] args) {
		int[] d1 = {1,3,2,5,4};
		int[] d2 = {2,2,3,3};
		System.out.println(solution(d1, 9));
		System.out.println(solution(d2, 10));
	}
}
