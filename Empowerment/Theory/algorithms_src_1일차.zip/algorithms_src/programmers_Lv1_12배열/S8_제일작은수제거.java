package programmers_Lv1_12배열;
import java.util.*;
public class S8_제일작은수제거 {
    static int min = 10000;
    public static int[] solution(int[] arr) {
        if(arr.length>1) {          
            //int min = Arrays.stream(arr).min().getAsInt();      
            for(int i=0;i<arr.length; i++)
                if(arr[i]<min) min=arr[i];
            ArrayList<Integer> list = new ArrayList<>();
            for (int i=0; i<arr.length; i++){
                if(arr[i]!=min) list.add(arr[i]);
            }
            int[] answer = new int[list.size()];
            for (int i=0; i<answer.length; i++)
                answer[i] = list.get(i);          
            return answer;          
        } else {
        	// return new int[] {-1};
        	int[] answer = {-1};
        	return answer;
        }
    }
	public static void main(String[] args) {
		int[] arr1 = {4,3,2,1};
		int[] arr2 = {10};
		System.out.println(Arrays.toString(solution(arr1)));
		System.out.println(Arrays.toString(solution(arr2)));
	}

}
