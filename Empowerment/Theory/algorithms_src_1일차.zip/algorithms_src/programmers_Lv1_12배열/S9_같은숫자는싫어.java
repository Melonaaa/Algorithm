package programmers_Lv1_12배열;
import java.util.*;
public class S9_같은숫자는싫어 {
    public static int[] solution(int []arr) {
        ArrayList<Integer> list = new ArrayList<>();
        for(int i=0; i<arr.length; i++){
            if(i==0 || arr[i-1] != arr[i])  // i==0 부터 처리해야 함
                list.add(arr[i]);
            else if (arr[i-1]==arr[i])
                continue;
        }
        int[] answer = new int[list.size()];        
        for (int i=0; i<list.size(); i++)
            answer[i] = list.get(i);
        return answer;
    }
	public static void main(String[] args) {
		int[] arr1 = {1,1,3,3,0,1,1};
		int[] arr2 = {4,4,4,3,3};
		System.out.println(Arrays.toString(solution(arr1)));
		System.out.println(Arrays.toString(solution(arr2)));
	}

}
