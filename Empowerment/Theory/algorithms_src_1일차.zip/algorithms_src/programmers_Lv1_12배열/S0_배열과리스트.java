package programmers_Lv1_12배열;
//import java.util.ArrayList;
//import java.util.Arrays;
import java.util.*;
public class S0_배열과리스트 {
	public static void solution(int n) {
		int[] arr = new int[n];
		for (int i=0; i<arr.length; i++) {
			arr[0]= 0;
		}
		System.out.println(Arrays.toString(arr));
		
		ArrayList<Integer> arrList = new ArrayList<>();
		for (int i=0; i<5; i++) {
			arrList.add(i);
		}
		arrList.remove(0);
		for(int i = 0; i < arrList.size(); i++) {
		    System.out.println("Element: " + arrList.get(i));
		}
	}
	public static void main(String[] args) {
		solution(5);
	}
}
