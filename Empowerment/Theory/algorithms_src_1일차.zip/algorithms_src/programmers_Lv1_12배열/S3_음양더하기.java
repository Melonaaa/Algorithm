package programmers_Lv1_12배열;

public class S3_음양더하기 {
    public static int solution(int[] absolutes, boolean[] signs) {
        int answer = 0;
        for(int i=0; i<absolutes.length; i++) {
            if (signs[i]==false)
                absolutes[i]*=-1;
            answer += absolutes[i];
        }
        return answer;
    }
	public static void main(String[] args) {
		int[] a1 = {4,7,12};
		boolean[] s1 = {true,false,true};
		int[] a2 = {1,2,3};
		boolean[] s2 = {false,false,true};
		System.out.println(solution(a1,s1));
		System.out.println(solution(a2,s2));
	}

}
