package programmers_Lv1_14문자열응용;
import java.util.*;

public class S3_문자열내마음대로정렬 {
    public static String[] solution(String[] strings, int n) {
        String[] answer = new String[strings.length];
        ArrayList<String> arrList = new ArrayList<>();
        for (int i=0; i<strings.length; i++)
        	arrList.add(strings[i].charAt(n)+strings[i]);
        
        Collections.sort(arrList);
        for (int i=0; i<strings.length; i++)
            answer[i] = arrList.get(i).substring(1,arrList.get(i).length());
        return answer;
    }
	public static void main(String[] args) {
		String[] strings1 = {"sun", "bed", "car"};
		String[] strings2 = {"abce", "abcd", "cdx"};
        System.out.println(Arrays.toString(solution(strings1,1)));
        System.out.println(Arrays.toString(solution(strings2,2)));
	}
}
