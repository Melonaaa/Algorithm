package programmers_Lv1_14문자열응용;

public class S4_이상한문자 {
    public static String solution(String s) {
        String answer = "";
        String[] str = s.split("");
        int index=0;

        for (String ss : str) {
            if (ss.equals(" ")) {
                index = 0;
                answer += " ";
            }
            else {
                if (index%2==0) 
                	answer += ss.toUpperCase();
                else
                    answer += ss.toLowerCase();
                index++;
            }
        }
/*
        for(String ss : str) {
        	index = ss.equals(" ") ? 0 : index + 1; // 첫번째 또는 0번 인덱스는 통과(소문자)
            answer += index%2 == 0 ? ss.toLowerCase() : ss.toUpperCase(); 
        }
*/         
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution("try hello world"));
	}
}
