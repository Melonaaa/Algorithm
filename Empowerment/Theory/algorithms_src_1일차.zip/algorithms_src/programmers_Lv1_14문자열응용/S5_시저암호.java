package programmers_Lv1_14문자열응용;

public class S5_시저암호 {
    public static String solution(String s, int n) {
        String answer = "";
        for(int i=0; i<s.length(); i++){
            if (s.charAt(i) == ' ') 
            	answer += " ";    
            else if (s.charAt(i) >= 97)
            	answer += (char)( 'a' + (s.charAt(i)+n-'a')%26 );
            else
            	answer += (char)( 'A' + (s.charAt(i)+n-'A')%26 );
        }
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution("AB",1));
        System.out.println(solution("z",1));
        System.out.println(solution("a B z",4));
	}

}
