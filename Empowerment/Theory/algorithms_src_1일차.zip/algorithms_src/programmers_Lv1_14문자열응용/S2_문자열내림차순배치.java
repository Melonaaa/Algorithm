package programmers_Lv1_14문자열응용;
import java.util.*;
public class S2_문자열내림차순배치 {
    public static String solution(String s) {
        String answer = "";
        String[] str = s.split("");
        Arrays.sort(str);
        
        StringBuilder sb = new StringBuilder();
        for (String ss : str)
        	sb.append(ss);
        answer = sb.reverse().toString();
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution("Zbcdefg"));
        System.out.println(solution("abxpycdZijk"));
	}
}
