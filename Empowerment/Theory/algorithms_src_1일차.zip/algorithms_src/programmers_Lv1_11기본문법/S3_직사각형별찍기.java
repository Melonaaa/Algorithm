package programmers_Lv1_11기본문법;
import java.util.*;
public class S3_직사각형별찍기 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        for (int i=0; i<b; i++){
            for (int j=0; j<a; j++) {
                System.out.print("*");        
            }
            System.out.println();        
        }
        sc.close();
    }
}
