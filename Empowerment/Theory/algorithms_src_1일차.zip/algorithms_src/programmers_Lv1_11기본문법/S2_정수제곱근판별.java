package programmers_Lv1_11기본문법;
public class S2_정수제곱근판별 {
    public static long solution(long n) {
        long answer = (long)Math.sqrt(n);
        if (answer*answer == n)
            return (answer+1)*(answer+1);
        else
            return -1;
    }
	public static void main(String[] args) {
    	System.out.println(solution(121));
    	System.out.println(solution(3));
	}
}
