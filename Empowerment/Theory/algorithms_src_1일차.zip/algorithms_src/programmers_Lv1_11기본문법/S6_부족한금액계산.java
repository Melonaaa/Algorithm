package programmers_Lv1_11기본문법;
public class S6_부족한금액계산 {
    public static long solution(int price, int money, int count) {
        long answer = -1;
        long total = 0;
        for(int i=1; i<=count; i++) {
            total += (price*i);
        }
        if (money>total) answer = 0;
        else answer = total-money;
        return answer;
    }
    public static void main(String[] args) {      
        System.out.println(solution(3,20,4));
    }
}
