package programmers_Lv1_11기본문법;

public class S1_짝수와홀수 {
    public static String solution(int num) {
        String answer = "";
        if (num%2==0) answer="Even";
        else answer="Odd";
        return answer;
    }
	public static void main(String[] args) {
    	System.out.println(solution(3));
    }
}
