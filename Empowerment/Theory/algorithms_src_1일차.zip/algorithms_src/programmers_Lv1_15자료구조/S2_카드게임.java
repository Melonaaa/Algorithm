package programmers_Lv1_15자료구조;
import java.util.Queue;
import java.util.LinkedList;

public class S2_카드게임 {
    public static String solution(int[] arr) {
    	 Queue<Integer> queue = new LinkedList<>();
    	 for (int i=arr.length-1; i>=0; i--) { // 카드를 큐에 저장
    		 queue.add(arr[i]);
    	 }
    	 //System.out.println(queue.toString());
    	 while (queue.size() > 1) { // 카드가 1장 남을 때까지
    		 queue.poll(); 				// 맨 위의 카드를 버림
    		 queue.add(queue.poll()); // 맨 위의 카드를 가장 아래 카드 밑으로 이동
    		 //System.out.println(queue.toString());
    	 }
    	 return queue.toString();
    }
	public static void main(String[] args) {
		int[] arr = {6,5,4,3,2,1};
		System.out.println(solution(arr));
	}
}
