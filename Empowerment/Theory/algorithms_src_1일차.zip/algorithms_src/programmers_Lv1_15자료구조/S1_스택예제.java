package programmers_Lv1_15자료구조;
import java.util.Stack;

public class S1_스택예제 {
    public static String solution(int[] arr, int n) {
    	Stack<Integer> stack = new Stack<>();
    	for (int i=0; i<arr.length; i++)
    		stack.push(arr[i]);
    	for (Integer i : stack)
    		System.out.print(i+" ");
    	System.out.println();
    	if (n==1)
    		System.out.println(stack.pop());
    	else System.out.println(stack.peek());
    	return stack.toString();
    }
	public static void main(String[] args) {
		int[] arr1 = {8,4,3,6};
		int[] arr2 = {1,9,5,2,7};
		System.out.println(solution(arr1, 1));
		System.out.println(solution(arr2, 2));
	}
}
