package programmers_Lv1_13문자열;

public class S92_가운데글자 {
    public static String solution(String s) {
        String answer = "";
        //answer += s.substring((s.length()-1)/2, s.length()/2+1); // endIndex의 -1 위치까지
        if(s.length()%2==0) {
            answer += s.charAt((s.length()-1)/2);
            answer += s.charAt(s.length()/2);
        } else
            answer += s.charAt(s.length()/2);

        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution("abcde"));
        System.out.println(solution("qwer"));
	}
}
