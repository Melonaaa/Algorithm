package programmers_Lv1_13문자열;

public class S2_문자열을정수로바꾸기 {
    public int solution(String s) {
        int answer = 0;
        answer = Integer.parseInt(s);
        return answer;
    }
	public static void main(String[] args) {
		S2_문자열을정수로바꾸기 sol = new S2_문자열을정수로바꾸기();
        System.out.println(sol.solution("1234"));
        System.out.println(sol.solution("-1234"));
	}
}
