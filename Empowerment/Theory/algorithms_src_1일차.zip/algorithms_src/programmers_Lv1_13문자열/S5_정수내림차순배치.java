package programmers_Lv1_13문자열;
import java.util.*;

public class S5_정수내림차순배치 {
    public static long solution(long n) {
        long answer = 0;
        String[] str = String.valueOf(n).split("");
        Arrays.sort(str);
        
        StringBuilder sb = new StringBuilder();
        for( String s : str ) sb.append(s);
        
        answer = Long.parseLong(sb.reverse().toString());
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution(118372));;
	}
}
