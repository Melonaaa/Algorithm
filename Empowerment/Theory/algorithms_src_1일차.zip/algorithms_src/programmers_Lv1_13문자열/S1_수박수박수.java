package programmers_Lv1_13문자열;

public class S1_수박수박수 {
    public static String solution(int n) {
        String answer = "";
        for(int i=0; i<n; i++) {
            if(i%2==0) answer += "수";
            else answer += "박";
        }
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution(3));
        System.out.println(solution(4));
	}
}
