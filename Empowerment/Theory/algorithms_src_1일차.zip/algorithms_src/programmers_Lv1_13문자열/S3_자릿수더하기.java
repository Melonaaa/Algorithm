package programmers_Lv1_13문자열;

public class S3_자릿수더하기 {
    public static int solution(int n) {
        int answer = 0;
        String[] str = String.valueOf(n).split("");
        for (int i=0; i<str.length; i++) {
            answer += Integer.parseInt(str[i]);
        }
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution(123));
        System.out.println(solution(987));
	}
}
