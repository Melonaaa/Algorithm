package programmers_Lv1_13문자열;

public class S91_문자열내p와y개수 {
    public static boolean solution(String s) {
        boolean answer = true;
        int p=0, y=0;
        
        String[] str = s.split("");
        for (String ss : str){
            if(ss.equals("p") || ss.equals("P")) p++;
            if(ss.equals("y") || ss.equals("Y")) y++;
        }
        if(p==y) answer=true;
        else answer=false;
        return answer;
    }
	public static void main(String[] args) {
        System.out.println(solution("pPoooyY"));
        System.out.println(solution("Pyy"));
	}
}
