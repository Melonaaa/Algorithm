package programmers_Lv1_13문자열;
import java.util.*;

public class S4_자연수뒤집어배열로 {
    public static int[] solution(long n) {
        int index = 0;
        String[] str = String.valueOf(n).split("");
        int[] answer = new int[str.length];
        for (int i=str.length-1; i>=0; i--){
            answer[index] = Integer.parseInt(str[i]);
            index++;
        }
        return answer;
    }   
	public static void main(String[] args) {
        System.out.println(Arrays.toString(solution(12345)));
	}
}
